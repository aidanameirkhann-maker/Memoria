export default function App() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-semibold">New App</h1>
      <p className="text-muted-foreground">Describe what you want to build in the chat.</p>
    </main>
  );
}
