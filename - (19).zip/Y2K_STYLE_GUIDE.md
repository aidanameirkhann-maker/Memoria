# 🎨 Y2K GLAMOUR STYLE GUIDE

## Цветовая палитра

```css
--y2k-pink: #ff69b4;          /* Hot Pink */
--y2k-hot-pink: #ff1493;      /* Deep Pink */
--y2k-baby-pink: #ffb6c1;     /* Light Pink */
--y2k-turquoise: #40e0d0;     /* Turquoise */
--y2k-purple: #da70d6;        /* Orchid */
--y2k-lavender: #dda0dd;      /* Plum */
--y2k-silver: #c0c0c0;        /* Silver */
--y2k-gold: #ffd700;          /* Gold */
--y2k-leopard: #d4a574;       /* Leopard */
```

## Градиенты

### Основной фон
```css
background: linear-gradient(135deg, #ff69b4 0%, #da70d6 25%, #40e0d0 50%, #ffb6c1 75%, #ff69b4 100%);
background-size: 400% 400%;
animation: gradientShift 15s ease infinite;
```

### Кнопки
```css
/* Primary */
background: linear-gradient(135deg, var(--y2k-pink), var(--y2k-hot-pink));

/* Chrome */
background: linear-gradient(135deg, #e8e8e8 0%, #ffffff 50%, #a8a8a8 100%);

/* Replay */
background: linear-gradient(135deg, var(--y2k-purple), var(--y2k-lavender));
```

## Типографика

### Заголовки
- **Шрифт**: Comic Sans MS, Chalkboard SE, cursive
- **Стиль**: Bold, uppercase, letter-spacing: 1-2px
- **Эффекты**: Text-shadow с розовым свечением

### Текст
- **Шрифт**: Georgia, serif
- **Размер**: 15-16px
- **Line-height**: 1.6-1.8

## Эффекты и анимации

### Sparkle (Блёстки)
```css
@keyframes sparkle {
  0%, 100% { opacity: 0; transform: scale(0); }
  50% { opacity: 1; transform: scale(1); }
}
```

### Shimmer (Перелив)
```css
@keyframes shimmer {
  0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
  100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
}
```

### Pulse (Пульсация)
```css
@keyframes pulse {
  0%, 100% { box-shadow: 0 6px 24px rgba(255, 20, 147, 0.6); }
  50% { box-shadow: 0 8px 32px rgba(255, 20, 147, 0.8); }
}
```

### Gradient Shift
```css
@keyframes gradientShift {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
```

## Компоненты

### Карточки (Y2K Card)
- Border: 3px solid var(--y2k-pink)
- Border-radius: 25px
- Background: rgba(255, 255, 255, 0.85)
- Backdrop-filter: blur(20px)
- Box-shadow: 0 8px 32px rgba(255, 105, 180, 0.4)
- Shimmer overlay

### Кнопки
- Border-radius: 50px (pill shape)
- Border: 3px solid
- Text-transform: uppercase
- Letter-spacing: 1px
- Font-weight: bold

### FAB (Floating Action Button)
- Width/Height: 64px
- Border-radius: 50%
- Border: 3px solid white
- Pulse animation
- Box-shadow с розовым свечением

## Декоративные элементы

### Леопардовый бордер
```css
background: 
  radial-gradient(circle at 20% 30%, #8b6f47 0%, #8b6f47 8%, transparent 8%),
  radial-gradient(circle at 60% 20%, #8b6f47 0%, #8b6f47 6%, transparent 6%);
background-color: #d4a574;
```

### Неоновое свечение
```css
text-shadow: 
  2px 2px 0 var(--y2k-baby-pink),
  4px 4px 0 rgba(255, 105, 180, 0.3);
```

### Стеклянный эффект
```css
backdrop-filter: blur(20px);
-webkit-backdrop-filter: blur(20px);
background: rgba(255, 255, 255, 0.85);
border: 3px solid var(--y2k-pink);
```

## Иконки и эмодзи

Используются для Y2K атмосферы:
- ✨ Sparkles
- 💖 Heart
- 💎 Gem
- 🌊 Wave
- 🎵 Music
- 💿 CD
- 🦋 Butterfly
- 👑 Crown
- 💫 Dizzy
- 🌅 Sunset
- 🍂 Leaf
- 🌙 Moon

## Адаптивность

### Mobile (до 768px)
- Full width
- Touch-friendly размеры (min 44px)
- Vertical layout

### Desktop (768px+)
- Max-width: 430px
- Centered with border
- Enhanced shadows

## Производительность

- Canvas анимации оптимизированы
- requestAnimationFrame для плавности
- Минимум DOM манипуляций
- CSS анимации вместо JS где возможно

## Кастомизация

### Изменить цветовую схему
Отредактируйте CSS переменные в `:root`

### Добавить новые анимации
Добавьте @keyframes в CSS и примените через класс

### Изменить шрифты
Замените `--font-y2k` и `--font-glam` в `:root`

### Добавить больше блёсток
Увеличьте количество sparkle элементов в `createSparkles()`

---

**Y2K Forever** 💖✨🌟
